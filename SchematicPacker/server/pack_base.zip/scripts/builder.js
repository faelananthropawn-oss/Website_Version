import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const MAX_FUNCTIONS = 22;              //Well Hello There
const playerBuildLocation = new Map();

function runFunctionSeries(player, startIndex = 1) {
    const buildData = playerBuildLocation.get(player.id);
    if (!buildData || !buildData.location) {
        player.sendMessage("You haven't yet loaded a build.");
        return;
    }

    let current = startIndex;
    const loc = buildData.location;

    player.runCommandAsync("gamerule functionCommandLimit 10000");
    player.runCommandAsync("tp @s ~~~ facing ~1~~1");

    const runNext = () => {
        if (current > MAX_FUNCTIONS) {
            player.sendMessage("§aBuild Cycle Complete");
            return;
        }

        player.runCommandAsync(`execute positioned ${loc.x} ${loc.y} ${loc.z} run function function_part_${current}`);
        current++;
        system.runTimeout(runNext, 5);
    };

    runNext();
}

function showMainForm(player) {
    const form = new ActionFormData()
        .title("Build Loader")
        .body("\n\n\n")
        .button("Continue From Last Location")
        .button("Load Build From Current Location")
        .button("Need Help?");

    form.show(player).then(response => {
        if (response.canceled) return;
        const loc = { ...player.location };
        const playerId = player.id;
        if (response.selection === 0) {
            runFunctionSeries(player);
        }

        if (response.selection === 1) {
            const savedData = playerBuildLocation.get(playerId);
            if (savedData && savedData.location) {
                const confirmationForm = new ActionFormData()
                    .title("Confirm New Build Start")
                    .body("You have previously loaded a build. Are you sure you want to start a new build from your current location?")
                    .button("Yes")
                    .button("No");

                confirmationForm.show(player).then(confirmationResponse => {
                    if (confirmationResponse.canceled) return;

                    if (confirmationResponse.selection === 0) {
                        playerBuildLocation.set(playerId, { location: loc });
                        player.sendMessage("§aBuild Cycle Started\n\nOnce it says Build Cycle Completed if the whole build hasn't spawned, fly to the unloaded areas and click Continue From Last Location");
                        runFunctionSeries(player);
                    } else {
                        player.sendMessage("§cNew build has been cancelled.");
                    }
                });
            } else {
                playerBuildLocation.set(playerId, { location: loc });
                player.sendMessage("§aBuild Cycle Started\n\nOnce it says Build Cycle Completed if the whole build hasn't spawned, fly to the unloaded areas and click Continue From Last Location");
                runFunctionSeries(player);
            }
        }

        if (response.selection === 2) {
            const helpForm = new ActionFormData()
                .title("Help - Build Loader")
                .body("How to use the build loader:\n\n- Click 'Load Build From Current Location' to start spawning the build from where you are standing.\n(The build will load in the positive X and Z direction)\n\n- If the build doesn't fully spawn go to a unloaded part of the build and click 'Continue From Last Location' to resume.\n\nIf you need more help feel free to message me on discord.")
                .button("Back");

            helpForm.show(player).then(helpResponse => {
                if (helpResponse.canceled) return;
                if (helpResponse.selection === 0) {
                    showMainForm(player); 
                }
            });
        }
    });
}

world.beforeEvents.itemUse.subscribe((event) => {
    const player = event.source;
    if (!player?.isValid() || event.itemStack.typeId !== "original:name") return;

    system.run(() => {
        showMainForm(player);
    });
});